package com.capg.SpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootPackageLayerdApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootPackageLayerdApplication.class, args);
	}

}
