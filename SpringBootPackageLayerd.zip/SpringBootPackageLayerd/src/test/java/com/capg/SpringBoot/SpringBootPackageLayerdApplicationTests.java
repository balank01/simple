package com.capg.SpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootPackageLayerdApplicationTests {

	@Test
	void contextLoads() {
	}

}
